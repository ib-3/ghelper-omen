using System;
using System.Collections.Generic;
using System.Diagnostics;
using HP.Omen.Core.Common.Analytics;
using HP.Omen.Core.Common.Enums;
using HP.Omen.Core.Common.Events;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;

namespace HP.Omen.Core.Common.JSON;

[Serializable]
public class OmenNotification : BindableBase
{
	private string _downloadText = string.Empty;

	private string _downloadUrl = string.Empty;

	private string _type = string.Empty;

	private string _message = string.Empty;

	private string _id = string.Empty;

	private string _promotedPage = string.Empty;

	private string _promotedPageSecondLevel = string.Empty;

	private string _title = string.Empty;

	private string _appLogoImageUrl = string.Empty;

	private string _heroImageUrl = string.Empty;

	private string _friendlyId = string.Empty;

	private string _toastTag = string.Empty;

	private string _scheduleAt = string.Empty;

	private string _category = string.Empty;

	private string _subCategory = string.Empty;

	private long _expiryTimeStamp;

	private long _activeFromTimestamp;

	private long _reShowTimeDuration;

	private NotificationType _notificationType = NotificationType.IN_APP;

	private bool _isWarning;

	[JsonProperty("title")]
	public string Title
	{
		get
		{
			return _title;
		}
		set
		{
			if (value != _title)
			{
				_title = value;
			}
		}
	}

	[JsonProperty("appLogoImageUrl")]
	public string AppLogoImageUrl
	{
		get
		{
			return _appLogoImageUrl;
		}
		set
		{
			if (value != _appLogoImageUrl)
			{
				_appLogoImageUrl = value;
			}
		}
	}

	[JsonProperty("heroImageUrl")]
	public string HeroImageUrl
	{
		get
		{
			return _heroImageUrl;
		}
		set
		{
			if (value != _heroImageUrl)
			{
				_heroImageUrl = value;
			}
		}
	}

	[JsonProperty("notificationType")]
	public NotificationType NotificationType
	{
		get
		{
			return _notificationType;
		}
		set
		{
			if (value != _notificationType)
			{
				_notificationType = value;
			}
		}
	}

	[JsonProperty("urlDisplay")]
	public string DownloadText
	{
		get
		{
			return _downloadText;
		}
		set
		{
			if (value != _downloadText)
			{
				_downloadText = value;
			}
		}
	}

	[JsonProperty("id")]
	public string Id
	{
		get
		{
			return _id;
		}
		set
		{
			if (value != _id)
			{
				_id = value;
			}
		}
	}

	[JsonProperty("promotedPage")]
	public string PromotedPage
	{
		get
		{
			return _promotedPage;
		}
		set
		{
			if (value != _promotedPage)
			{
				_promotedPage = value;
			}
		}
	}

	[JsonProperty("promotedPageSecondLevel")]
	public string PromotedPageSecondLevel
	{
		get
		{
			return _promotedPageSecondLevel;
		}
		set
		{
			if (value != _promotedPageSecondLevel)
			{
				_promotedPageSecondLevel = value;
			}
		}
	}

	[JsonProperty("url")]
	public string DownloadUrl
	{
		get
		{
			return _downloadUrl;
		}
		set
		{
			if (value != _downloadUrl)
			{
				_downloadUrl = value;
			}
		}
	}

	[JsonProperty("level")]
	public string Type
	{
		get
		{
			return _type;
		}
		set
		{
			if (value != _type)
			{
				_type = value.ToUpper();
				IsWarning = _type == "WARNING" || _type == "OUTAGE";
			}
		}
	}

	[JsonProperty("message")]
	public string Message
	{
		get
		{
			return _message;
		}
		set
		{
			if (value != _message)
			{
				_message = value;
			}
		}
	}

	[JsonProperty("friendlyId")]
	public string FriendlyId
	{
		get
		{
			return _friendlyId;
		}
		set
		{
			if (value != _friendlyId)
			{
				_friendlyId = value;
			}
		}
	}

	[JsonProperty("ToastTag")]
	public string ToastTag
	{
		get
		{
			return _toastTag;
		}
		set
		{
			if (value != _toastTag)
			{
				_toastTag = value;
			}
		}
	}

	[JsonProperty("scheduleAt")]
	public string ScheduleAt
	{
		get
		{
			return _scheduleAt;
		}
		set
		{
			if (value != _scheduleAt)
			{
				_scheduleAt = value;
			}
		}
	}

	[JsonProperty("category")]
	public string Category
	{
		get
		{
			return _category;
		}
		set
		{
			if (value != _category)
			{
				_category = value;
			}
		}
	}

	[JsonProperty("subCategory")]
	public string SubCategory
	{
		get
		{
			return _subCategory;
		}
		set
		{
			if (value != _subCategory)
			{
				_subCategory = value;
			}
		}
	}

	[JsonProperty("expirationTimestamp")]
	public long ExpiryTimeStamp
	{
		get
		{
			return _expiryTimeStamp;
		}
		set
		{
			if (value != _expiryTimeStamp)
			{
				_expiryTimeStamp = value;
			}
		}
	}

	[JsonProperty("activeFromTimestamp")]
	public long ActiveFromTimestamp
	{
		get
		{
			return _activeFromTimestamp;
		}
		set
		{
			if (value != _activeFromTimestamp)
			{
				_activeFromTimestamp = value;
			}
		}
	}

	[JsonProperty("reShowTimeDuration")]
	public long ReShowTimeDuration
	{
		get
		{
			return _reShowTimeDuration;
		}
		set
		{
			if (value != _reShowTimeDuration)
			{
				_reShowTimeDuration = value;
			}
		}
	}

	[JsonProperty("buttons")]
	public OmenToastButton[] ToastButtons { get; set; }

	[JsonProperty("notificationSubType")]
	public string NotificationSubType { get; set; } = string.Empty;


	[JsonProperty("repeatCount")]
	public int RepeatCount { get; set; } = 3;


	[JsonProperty("priority")]
	public int Priority { get; set; }

	[JsonProperty("showAfterDays")]
	public int ShowAfterDays { get; set; }

	[JsonProperty("forceReshow")]
	public bool ForceReshow { get; set; }

	[JsonProperty("notificationAction")]
	public string NotificationAction { get; set; }

	[JsonProperty("includeGames")]
	public List<string> IncludeGames { get; set; } = new List<string>();


	[JsonProperty("blockGames")]
	public List<string> BlockGames { get; set; } = new List<string>();


	[JsonProperty("queryType")]
	public string CustomTypeName { get; set; }

	[JsonProperty("gameTags")]
	public List<RecommendationGame> RecommendationGames { get; set; }

	[JsonProperty("duration")]
	public long Duration { get; set; } = 5L;


	public bool IsWarning
	{
		get
		{
			return _isWarning;
		}
		set
		{
			_isWarning = value;
		}
	}

	public bool DontAskAgain { get; set; }

	public NotificationTarget NotificationTarget { get; set; }

	public DelegateCommand UrlCommand { get; set; }

	public DelegateCommand RemoveCommand { get; set; }

	[JsonConstructor]
	public OmenNotification()
	{
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Expected O, but got Unknown
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Expected O, but got Unknown
		UrlCommand = new DelegateCommand((Action)UrlExecute);
		RemoveCommand = new DelegateCommand((Action)RemoveExecute);
	}

	private void RemoveExecute()
	{
		((PubSubEvent<string>)Mediator.EventAggregator.GetEvent<NotificationRemovedEvent>()).Publish(Id);
	}

	private void UrlExecute()
	{
		if (DownloadUrl != string.Empty)
		{
			try
			{
				CloudServiceAnalytics.TrackNotificationClicked(Message).ConfigureAwait(continueOnCapturedContext: false);
				Process.Start(DownloadUrl);
			}
			catch (Exception)
			{
			}
		}
	}
}
