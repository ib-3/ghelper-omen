using System;
using Newtonsoft.Json;
using Prism.Mvvm;

namespace HP.Omen.Core.Common.JSON;

[Serializable]
public class OmenToastButton : BindableBase
{
	[JsonProperty("btnText")]
	public string ToastButtonText { get; set; } = string.Empty;


	[JsonProperty("iconUrl")]
	public string ToastButtonIconUrl { get; set; } = string.Empty;


	[JsonProperty("btnAction")]
	public string ToastButtonAction { get; set; } = string.Empty;


	[JsonProperty("orderNo")]
	public int ToastButtonOrder { get; set; }
}
