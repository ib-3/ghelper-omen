using System;
using Newtonsoft.Json;
using Prism.Mvvm;

namespace HP.Omen.Core.Common.JSON;

[Serializable]
public class NotificationTarget : BindableBase
{
	[JsonProperty("metadataId")]
	public string OmenAIMetadataId { get; set; }

	[JsonProperty("appId")]
	public string OmenAiAppId { get; set; }

	[JsonProperty("gameName")]
	public string OmenAIGameName { get; set; }

	[JsonProperty("content")]
	public string Content { get; set; }

	[JsonConstructor]
	public NotificationTarget()
	{
	}
}
