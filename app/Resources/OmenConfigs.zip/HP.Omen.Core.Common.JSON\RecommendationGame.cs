using System;
using Newtonsoft.Json;
using Prism.Mvvm;

namespace HP.Omen.Core.Common.JSON;

[Serializable]
public class RecommendationGame : BindableBase
{
	public string AutomationId => $"Download{OrderNo}";

	[JsonProperty("orderNo")]
	public int OrderNo { get; set; }

	[JsonProperty("gameImageUrl")]
	public string ImagePath { get; set; }

	[JsonProperty("downloadLink")]
	public string DownloadPath { get; set; }
}
